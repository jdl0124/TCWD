Public Class DetailReport

End Class
